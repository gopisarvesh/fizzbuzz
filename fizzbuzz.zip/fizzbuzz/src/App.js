import { type } from '@testing-library/user-event/dist/type';
import './App.css'
import { useState,useEffect } from "react";



function App() {

  

  let arrofobj= [
    {
      name: "Object 1",
      number: 7,
      type:'Fizzz'
    },
    {
      name: "Object 2",
      number: 3,
      type:'Fizz'
    },
    {
      name: "Object 3",
      number: 5,
      type:'Buzz'
    },
    {
      name: "Object 4",
      number: 15,
      type:'FizzBuzz'
    },
    {
      name: "Object 5",
      number: 15,
      type:'FizzBuzz'
    },
    {
      name: "Object 6",
      number: -12,
      type:'fizzz'
    },
    {
      name: "Object 6.5",
      number: -30,
      type:'FizzBuzz'
    },
    {
      name: "Object 7",
      number: -7,
      type:'fizz'
    }
  ];

const [data,setData]=useState(arrofobj)
const [formvalues,setFormvalues]=useState([])
const [name,setName]=useState('')
const [number,setNumber]=useState('')
const [type,setType]=useState('')

const handleClick=()=>{

  let obj={"name":name,"number":number,"type":type}
setFormvalues([...formvalues,obj]);
console.log(formvalues);
}



  return (
    <div className="">
      <h4>Fizz Buzz</h4>
<div>
<form>
  <input type='text' name='name' placeholder='Name' onChange={(e)=>setName(e.target.value)} /><br />
  <input type='text' name='number' placeholder='Number' onChange={(e)=>setNumber(e.target.value)} /> <br />
  <input type='text' name='type' placeholder='Type' onChange={(e)=>setType(e.target.value)} /><br />
  <input type='button' name="button" value="Submit" onClick={handleClick} />
</form>
</div>
<br />
<table border="1">
<tr>
<td>Name</td>
<td>Type</td>
</tr>
{

formvalues.map((item,index)=>{
  return <tr>
    <td>{item.name}</td>
    <td>{
      
      (item.number%3===0 && item.number%5===0)?'FizzBuzz':
      
      item.number%3===0?'Fizz':item.number%5===0?'Buzz':'idk'
  
 
  }
  
    </td>
  </tr>
})

}

</table>

    </div>
  );
}

export default App;
